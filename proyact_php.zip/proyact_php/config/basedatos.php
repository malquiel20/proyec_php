<?php
return [
'host' => 'localhost',
'nombre' => 'db_banco_adso',
'usuario' => 'root',
'contrasena' => 'Adso2026*',
'charset'=> 'utf8mb4'
];