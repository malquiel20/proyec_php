<?php
require 'vendor/autoload.php';

use App\Nucleo\Conexion;

try {
    $pdo = Conexion::obtenerConexion();
    echo "✓ Conexión exitosa a la base de datos";
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage();
}