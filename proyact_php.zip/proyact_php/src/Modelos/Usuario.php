<?php
namespace App\Modelos;


class Usuario
{
    public function __construct(
        private int $id,
        private int $cuentaId,
        private string $claveHash
    ) {}

    public static function desdeFila(array $fila): self
    {
        return new self((int) $fila['id'], (int) $fila['cuenta_id'], $fila['clave_hash']);
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getCuentaId(): int
    {
        return $this->cuentaId;
    }

    public function verificarClave(string $clave): bool
    {
        return password_verify($clave, $this->claveHash);
    }
}
