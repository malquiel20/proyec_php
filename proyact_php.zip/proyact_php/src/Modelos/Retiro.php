<?php
namespace App\Modelos;


class Retiro
{
    public function __construct(
        private int $id,
        private int $cuentaId,
        private float $valor,
        private string $fecha
    ) {}


    public static function desdeFila(array $fila): self
    {
        return new self(
            (int) $fila['id'],
            (int) $fila['cuenta_id'],
            (float) $fila['valor'],
            $fila['fecha']
        );
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getCuentaId(): int
    {
        return $this->cuentaId;
    }

    public function getValor(): float
    {
        return $this->valor;
    }

    public function getFecha(): string
    {
        return $this->fecha;
    }
}
