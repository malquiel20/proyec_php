<?php
namespace App\Modelos;

class Cliente
{
    public function __construct(
        private int $id,
        private string $nombre
    ) {}

    public static function desdeFila(array $fila): self
    {
        return new self((int) $fila['id'], $fila['nombre']);
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getNombre(): string
    {
        return $this->nombre;
    }
}
