<?php
namespace App\Modelos;

/**
 * Representa una transferencia entre dos cuentas (tabla: transferencias).
 */
class Transferencia
{
    public function __construct(
        private int $id,
        private int $cuentaOrigenId,
        private int $cuentaDestinoId,
        private float $valor,
        private string $fecha
    ) {}

    public static function desdeFila(array $fila): self
    {
        return new self(
            (int) $fila['id'],
            (int) $fila['cuenta_origen_id'],
            (int) $fila['cuenta_destino_id'],
            (float) $fila['valor'],
            $fila['fecha']
        );
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getCuentaOrigenId(): int
    {
        return $this->cuentaOrigenId;
    }

    public function getCuentaDestinoId(): int
    {
        return $this->cuentaDestinoId;
    }

    public function getValor(): float
    {
        return $this->valor;
    }

    public function getFecha(): string
    {
        return $this->fecha;
    }

    public function esSalidaPara(int $cuentaId): bool
    {
        return $this->cuentaOrigenId === $cuentaId;
    }
}
