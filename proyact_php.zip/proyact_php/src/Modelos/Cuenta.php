<?php
namespace App\Modelos;

use InvalidArgumentException;

class Cuenta
{
    public function __construct(
        private int $id,
        private string $numeroCuenta,
        private float $saldo,
        private int $clienteId
    ) {}


    public static function desdeFila(array $fila): self
    {
        return new self(
            (int) $fila['id'],
            $fila['numero_cuenta'],
            (float) $fila['saldo'],
            (int) $fila['cliente_id']
        );
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getNumeroCuenta(): string
    {
        return $this->numeroCuenta;
    }

    public function getSaldo(): float
    {
        return $this->saldo;
    }

    public function getClienteId(): int
    {
        return $this->clienteId;
    }

    public function debitar(float $valor): void
    {
        if ($valor <= 0) {
            throw new InvalidArgumentException('El valor debe ser mayor que cero.');
        }
        if ($valor > $this->saldo) {
            throw new InvalidArgumentException('Saldo insuficiente.');
        }
        $this->saldo = round($this->saldo - $valor, 2);
    }

    public function acreditar(float $valor): void
    {
        if ($valor <= 0) {
            throw new InvalidArgumentException('El valor debe ser mayor que cero.');
        }
        $this->saldo = round($this->saldo + $valor, 2);
    }
}
