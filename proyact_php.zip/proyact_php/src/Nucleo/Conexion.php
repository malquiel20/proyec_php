<?php
declare(strict_types=1);
namespace App\Nucleo;
use PDO;
class Conexion{
    private static ?PDO $conexion=null;
    private function __construct(){} 
    public static function obtenerConexion(): PDO
    {
        $config=require __DIR__."/../../config/basedatos.php";   
        if (self::$conexion === null) {
            
            $configs = sprintf("mysql:host=%s;dbname=%s;charset=%s",
            $config["host"],
            $config["nombre"],
            $config["charset"]);

            
            self::$conexion = new PDO(
                $configs,
                $config["usuario"],
                $config["contrasena"]
            );
        }
        return self::$conexion;
    }
}
?>