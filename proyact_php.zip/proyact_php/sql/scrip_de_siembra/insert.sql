USE db_banco_adso;

INSERT INTO clientes (id, nombre) VALUES
    (1, 'Luis Fernando Gomez'),
    (2, 'Malquiel Tirado'),
    (3, 'Magguier Torres'),
    (4, 'Jailer Rojas'),
    (5, 'Cristian Perez');

INSERT INTO cuentas (id, numero_cuenta, saldo, cliente_id) VALUES
    (1, '1001000001', 5000000.00, 1),
    (2, '1001000002', 8500000.00, 2),
    (3, '1001000003', 3200000.00, 3),
    (4, '1001000004', 1200000.00, 4),
    (5, '1001000005', 4700000.00, 5);

INSERT INTO usuarios (id, cuenta_id, clave_hash) VALUES
    (1, 1, '$argon2id$v=19$m=19456,t=2,p=1$sPW7Hx9swY3p73WQaaeJ+Q$yVjKvy58UeZhvUB0DUUXoijv45m7WhO6WHDqKZkLTL4'),
    (2, 2, '$argon2id$v=19$m=19456,t=2,p=1$sPW7Hx9swY3p73WQaaeJ+Q$Pls3DSGh7PUZ8MlLv5ClamaXAbI+MK8Wlf9OhVPFEKk'),
    (3, 3, '$argon2id$v=19$m=19456,t=2,p=1$sPW7Hx9swY3p73WQaaeJ+Q$sEwPudd1x/LC3jeCLmPLR6k7KwOlFqoR1ssdxi2hcl8'),
    (4, 4, '$argon2id$v=19$m=19456,t=2,p=1$sPW7Hx9swY3p73WQaaeJ+Q$IF/5xyR7i9Pm8vA9ql43EqVVqatkHFwvtntPfIOpFqo'),
    (5, 5, '$argon2id$v=19$m=19456,t=2,p=1$sPW7Hx9swY3p73WQaaeJ+Q$V+BFOhytuXhIOOsY24RpzwOzuhjCnv2psQPY/rUB1sY');