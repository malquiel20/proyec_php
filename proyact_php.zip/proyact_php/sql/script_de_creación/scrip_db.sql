CREATE DATABASE IF NOT EXISTS db_banco_adso
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE db_banco_adso;

CREATE TABLE IF NOT EXISTS clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS cuentas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero_cuenta VARCHAR(20) NOT NULL,
    saldo DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    cliente_id INT NOT NULL,
    UNIQUE KEY uq_cuentas_numero_cuenta (numero_cuenta),
    CONSTRAINT fk_cuentas_cliente
        FOREIGN KEY (cliente_id) REFERENCES clientes (id)
        ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cuenta_id INT NOT NULL,
    clave_hash VARCHAR(255) NOT NULL,
    UNIQUE KEY uq_usuarios_cuenta_id (cuenta_id),
    CONSTRAINT fk_usuarios_cuenta
        FOREIGN KEY (cuenta_id) REFERENCES cuentas (id)
        ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS retiros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cuenta_id INT NOT NULL,
    valor DECIMAL(12, 2) NOT NULL,
    fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_retiros_cuenta
        FOREIGN KEY (cuenta_id) REFERENCES cuentas (id)
        ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS transferencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cuenta_origen_id INT NOT NULL,
    cuenta_destino_id INT NOT NULL,
    valor DECIMAL(12, 2) NOT NULL,
    fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_transferencias_origen
        FOREIGN KEY (cuenta_origen_id) REFERENCES cuentas (id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_transferencias_destino
        FOREIGN KEY (cuenta_destino_id) REFERENCES cuentas (id)
        ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;